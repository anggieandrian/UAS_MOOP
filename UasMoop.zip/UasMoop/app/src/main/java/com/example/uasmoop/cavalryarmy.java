package com.example.uasmoop;

public class cavalryarmy extends army {

	public cavalryarmy(int infantryPoint, int cavalryPoint, int archerPoint, int catapultPoint) {
		super(infantryPoint, cavalryPoint, archerPoint, catapultPoint);
		// TODO Auto-generated constructor stub
	}

}
