package com.example.uasmoop;

public class heroes {
	private int InfantryPoint;
	private int CavalryPoint;
	private int ArcherPoint;
	private int CatapultPoint;
	private int Level;
	
	public heroes(int infantryPoint, int cavalryPoint, int archerPoint, int catapultPoint, int level) {
		super();
		InfantryPoint = infantryPoint;
		CavalryPoint = cavalryPoint;
		ArcherPoint = archerPoint;
		CatapultPoint = catapultPoint;
		Level = level;
	}
	
	public int getInfantryPoint() {
		return InfantryPoint;
	}
	public void setInfantryPoint(int infantryPoint) {
		InfantryPoint = infantryPoint;
	}
	public int getCavalryPoint() {
		return CavalryPoint;
	}
	public void setCavalryPoint(int cavalryPoint) {
		CavalryPoint = cavalryPoint;
	}
	public int getArcherPoint() {
		return ArcherPoint;
	}
	public void setArcherPoint(int archerPoint) {
		ArcherPoint = archerPoint;
	}
	public int getCatapultPoint() {
		return CatapultPoint;
	}
	public void setCatapultPoint(int catapultPoint) {
		CatapultPoint = catapultPoint;
	}
	
	public int getLevel() {
		return Level;
	}
	public void setLevel(int level) {
		Level = level;
	}
	
	public void levelUp()
	{
		this.setArcherPoint(getArcherPoint()+20);
		this.setCatapultPoint(getCatapultPoint()+20);
		this.setCavalryPoint(getCavalryPoint()+20);
		this.setInfantryPoint(getInfantryPoint()+20);
		this.setLevel(getLevel()+1);
	}
	
}
