package com.example.uasmoop;

public class infantryheroes extends heroes {

	public infantryheroes(int infantryPoint, int cavalryPoint, int archerPoint, int catapultPoint, int level) {
		super(infantryPoint, cavalryPoint, archerPoint, catapultPoint, level);
		// TODO Auto-generated constructor stub
	}
	
	public void boost()
	{
		this.setInfantryPoint(this.getInfantryPoint()+(this.getInfantryPoint()*40)/100);
	}

}
