package com.example.uasmoop;

public class horsecastle extends castle{

	public horsecastle(int heroes, int army) {
		super(heroes, army);
		// TODO Auto-generated constructor stub
	}

	public int boost(int point)
	{
		point = point+((point*20)/100);
		return point;
	}
}
