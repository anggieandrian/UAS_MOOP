package com.example.uasmoop;

public class archerheroes extends heroes {

	public archerheroes(int infantryPoint, int cavalryPoint, int archerPoint, int catapultPoint, int level) {
		super(infantryPoint, cavalryPoint, archerPoint, catapultPoint, level);
		// TODO Auto-generated constructor stub
	}
	
	public void boost()
	{
		this.setArcherPoint(this.getArcherPoint()+(this.getArcherPoint()*40)/100);
	}

}
