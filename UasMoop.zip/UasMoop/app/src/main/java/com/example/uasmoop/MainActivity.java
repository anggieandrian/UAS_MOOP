package com.example.uasmoop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        player player1 = new player("Horse Castle", 6, 500);
        player player2 = new player("Wood Castle", 6, 500);
        player player3 = new player("Steel Castle", 6, 500);
        player player4 = new player("Stone Castle", 6, 500);

        ArrayList<catapultheroes> player1heroes = new ArrayList<catapultheroes>();
        player1heroes.add(new catapultheroes(100, 90, 80, 70, 1));
        player1heroes.add(new catapultheroes(90, 100, 70, 80, 1));
        player1heroes.add(new catapultheroes(80, 70, 100, 90, 1));
        player1heroes.add(new catapultheroes(90, 70, 80, 100, 1));
        player1heroes.add(new catapultheroes(10, 20, 30, 40, 1));
        player1heroes.add(new catapultheroes(80, 50, 30, 100, 1));

        for(int i = 0; i < player1heroes.size(); i++)
        {
            for (int j = 0; j< 49; j++)
            {
                player1heroes.get(i).levelUp();
            }
            player1heroes.get(i).boost();
        }

        ArrayList<archerheroes> player2heroes = new ArrayList<archerheroes>();
        player2heroes.add(new archerheroes(100, 90, 80, 70, 1));
        player2heroes.add(new archerheroes(90, 100, 70, 80, 1));
        player2heroes.add(new archerheroes(80, 70, 100, 90, 1));
        player2heroes.add(new archerheroes(90, 70, 80, 100, 1));
        player2heroes.add(new archerheroes(10, 20, 30, 40, 1));
        player2heroes.add(new archerheroes(80, 50, 30, 100, 1));

        for(int i = 0; i < player2heroes.size(); i++)
        {
            for (int j = 0; j< 49; j++)
            {
                player2heroes.get(i).levelUp();
            }
            player2heroes.get(i).boost();
        }

        ArrayList<cavalryheroes> player3heroes = new ArrayList<cavalryheroes>();
        player3heroes.add(new cavalryheroes(100, 90, 80, 70, 1));
        player3heroes.add(new cavalryheroes(90, 100, 70, 80, 1));
        player3heroes.add(new cavalryheroes(80, 70, 100, 90, 1));
        player3heroes.add(new cavalryheroes(90, 70, 80, 100, 1));
        player3heroes.add(new cavalryheroes(10, 20, 30, 40, 1));
        player3heroes.add(new cavalryheroes(80, 50, 30, 100, 1));

        for(int i = 0; i < player3heroes.size(); i++)
        {
            for (int j = 0; j< 49; j++)
            {
                player3heroes.get(i).levelUp();
            }
            player3heroes.get(i).boost();
        }

        ArrayList<infantryheroes> player4heroes = new ArrayList<infantryheroes>();
        player4heroes.add(new infantryheroes(100, 90, 80, 70, 1));
        player4heroes.add(new infantryheroes(90, 100, 70, 80, 1));
        player4heroes.add(new infantryheroes(80, 70, 100, 90, 1));
        player4heroes.add(new infantryheroes(90, 70, 80, 100, 1));
        player4heroes.add(new infantryheroes(10, 20, 30, 40, 1));
        player4heroes.add(new infantryheroes(80, 50, 30, 100, 1));

        for(int i = 0; i < player4heroes.size(); i++)
        {
            for (int j = 0; j< 49; j++)
            {
                player4heroes.get(i).levelUp();
            }
            player4heroes.get(i).boost();
        }


        System.out.println("4 Player played this game");
        System.out.println("===========================================================");
        System.out.println("===========================================================");
        System.out.println("Castle : "+player1.getCastleName());
        System.out.println("Heroes : "+player1.getHeroes());
        System.out.println("Armies : "+player1.getArmies());
        System.out.println("===========================================================");
        System.out.println("Heroes List");
        System.out.println("===========================================================");
        for(int i = 0; i<player1heroes.size();i++)
        {
            System.out.println("Infantry Point : " + player1heroes.get(i).getInfantryPoint());
            System.out.println("Cavalry Point : " + player1heroes.get(i).getCavalryPoint());
            System.out.println("Archer Point : " + player1heroes.get(i).getArcherPoint());
            System.out.println("Catapult Point : " + player1heroes.get(i).getCatapultPoint());
            System.out.println("Level : " + player1heroes.get(i).getLevel());
            System.out.println("===========================================================");
        }
        System.out.println("===========================================================");
        System.out.println("Castle : "+player2.getCastleName());
        System.out.println("Heroes : "+player2.getHeroes());
        System.out.println("Armies : "+player2.getArmies());
        System.out.println("===========================================================");
        System.out.println("Heroes List");
        System.out.println("===========================================================");
        for(int i = 0; i<player2heroes.size();i++)
        {
            System.out.println("Infantry Point : " + player2heroes.get(i).getInfantryPoint());
            System.out.println("Cavalry Point : " + player2heroes.get(i).getCavalryPoint());
            System.out.println("Archer Point : " + player2heroes.get(i).getArcherPoint());
            System.out.println("Catapult Point : " + player2heroes.get(i).getCatapultPoint());
            System.out.println("Level : " + player2heroes.get(i).getLevel());
            System.out.println("===========================================================");
        }
        System.out.println("===========================================================");
        System.out.println("Castle : "+player3.getCastleName());
        System.out.println("Heroes : "+player3.getHeroes());
        System.out.println("Armies : "+player3.getArmies());
        System.out.println("===========================================================");
        System.out.println("Heroes List");
        System.out.println("===========================================================");
        for(int i = 0; i<player3heroes.size();i++)
        {
            System.out.println("Infantry Point : " + player3heroes.get(i).getInfantryPoint());
            System.out.println("Cavalry Point : " + player3heroes.get(i).getCavalryPoint());
            System.out.println("Archer Point : " + player3heroes.get(i).getArcherPoint());
            System.out.println("Catapult Point : " + player3heroes.get(i).getCatapultPoint());
            System.out.println("Level : " + player3heroes.get(i).getLevel());
            System.out.println("===========================================================");
        }
        System.out.println("===========================================================");
        System.out.println("Castle : "+player4.getCastleName());
        System.out.println("Heroes : "+player4.getHeroes());
        System.out.println("Armies : "+player4.getArmies());
        System.out.println("===========================================================");
        System.out.println("Heroes List");
        System.out.println("===========================================================");
        for(int i = 0; i<player2heroes.size();i++)
        {
            System.out.println("Infantry Point : " + player4heroes.get(i).getInfantryPoint());
            System.out.println("Cavalry Point : " + player4heroes.get(i).getCavalryPoint());
            System.out.println("Archer Point : " + player4heroes.get(i).getArcherPoint());
            System.out.println("Catapult Point : " + player4heroes.get(i).getCatapultPoint());
            System.out.println("Level : " + player4heroes.get(i).getLevel());
            System.out.println("===========================================================");
        }
        System.out.println("===========================================================");
    }

    Button Battle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Battle=(Button)findViewById(R.id.button);

        Battle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                Toast toast = Toast.makeText(V.getContext(), "Cavalry WIN", Toast.LENGTH_SHORT);
                toast.show();

            }
        });
    }
}