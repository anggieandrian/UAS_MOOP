package com.example.uasmoop;

public class stonecastle extends castle {

	public stonecastle(int heroes, int army) {
		super(heroes, army);
		// TODO Auto-generated constructor stub
	}
	
	public int boost(int point)
	{
		point = point+((point*20)/100);
		return point;
	}

}
