package com.example.uasmoop;

public class infantryarmy extends army {

	public infantryarmy(int infantryPoint, int cavalryPoint, int archerPoint, int catapultPoint) {
		super(infantryPoint, cavalryPoint, archerPoint, catapultPoint);
		// TODO Auto-generated constructor stub
	}

}
