package com.example.uasmoop;

public class army {
	private int InfantryPoint;
	private int CavalryPoint;
	private int ArcherPoint;
	private int CatapultPoint;
	public army(int infantryPoint, int cavalryPoint, int archerPoint, int catapultPoint) {
		super();
		InfantryPoint = infantryPoint;
		CavalryPoint = cavalryPoint;
		ArcherPoint = archerPoint;
		CatapultPoint = catapultPoint;
	}
	public int getInfantryPoint() {
		return InfantryPoint;
	}
	public void setInfantryPoint(int infantryPoint) {
		InfantryPoint = infantryPoint;
	}
	public int getCavalryPoint() {
		return CavalryPoint;
	}
	public void setCavalryPoint(int cavalryPoint) {
		CavalryPoint = cavalryPoint;
	}
	public int getArcherPoint() {
		return ArcherPoint;
	}
	public void setArcherPoint(int archerPoint) {
		ArcherPoint = archerPoint;
	}
	public int getCatapultPoint() {
		return CatapultPoint;
	}
	public void setCatapultPoint(int catapultPoint) {
		CatapultPoint = catapultPoint;
	}
	
	
}
