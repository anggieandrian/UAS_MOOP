package com.example.uasmoop;

public class cavalryheroes extends heroes{

	public cavalryheroes(int infantryPoint, int cavalryPoint, int archerPoint, int catapultPoint, int level) {
		super(infantryPoint, cavalryPoint, archerPoint, catapultPoint, level);
		// TODO Auto-generated constructor stub
	}

	public void boost()
	{
		this.setCavalryPoint(this.getCavalryPoint()+(this.getCavalryPoint()*40)/100);
	}

}
