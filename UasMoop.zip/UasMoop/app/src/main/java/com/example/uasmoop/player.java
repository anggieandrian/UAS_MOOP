package com.example.uasmoop;

public class player {
	private String castleName;
	private int heroes;
	private int armies;
	public player(String castleName, int heroes, int armies) {
		super();
		this.castleName = castleName;
		this.heroes = heroes;
		this.armies = armies;
	}
	public String getCastleName() {
		return castleName;
	}
	public void setCastleName(String castleName) {
		this.castleName = castleName;
	}
	public int getHeroes() {
		return heroes;
	}
	public void setHeroes(int heroes) {
		this.heroes = heroes;
	}
	public int getArmies() {
		return armies;
	}
	public void setArmies(int armies) {
		this.armies = armies;
	}
	
	
}
