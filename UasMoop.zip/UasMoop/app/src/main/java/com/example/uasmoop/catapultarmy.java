package com.example.uasmoop;

public class catapultarmy extends army {

	public catapultarmy(int infantryPoint, int cavalryPoint, int archerPoint, int catapultPoint) {
		super(infantryPoint, cavalryPoint, archerPoint, catapultPoint);
		// TODO Auto-generated constructor stub
	}

}
