package com.example.uasmoop;

public class catapultheroes extends heroes {

	public catapultheroes(int infantryPoint, int cavalryPoint, int archerPoint, int catapultPoint, int level) {
		super(infantryPoint, cavalryPoint, archerPoint, catapultPoint, level);
		// TODO Auto-generated constructor stub
	}
	
	public void boost()
	{
		this.setCatapultPoint(this.getCatapultPoint()+(this.getCatapultPoint()*40)/100);
	}

}
