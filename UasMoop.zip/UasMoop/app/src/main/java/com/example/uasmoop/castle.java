package com.example.uasmoop;

public class castle {
	private int heroes;
	private int army;
	
	public castle(int heroes, int army) {
		super();
		this.heroes = heroes;
		this.army = army;
	}
	public int getHeroes() {
		return heroes;
	}
	public void setHeroes(int heroes) {
		this.heroes = heroes;
	}
	public int getArmy() {
		return army;
	}
	public void setArmy(int army) {
		this.army = army;
	}
	
	
}
